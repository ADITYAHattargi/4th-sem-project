# SkillBloom Upgrade: TODO.md

**Project**: Transform static prototype → Production-ready MERN full-stack app

## ✅ Completed (1/18)
- [x] 1.1 Backup existing files
- [x] 1.2 Create skillbloom/ project dir  
- [x] 1.3 Create TODO.md

## ⏳ Steps to Complete (Approved Plan)

### 1. **Backup & Setup** (High Priority)
- [x] Backup existing files: \`powershell "Compress-Archive -Path * -DestinationPath skillbloom-backup-\$(Get-Date -Format 'yyyyMMdd').zip"\`
- [ ] Create \`skillbloom/\` project dir
- [x] Create TODO.md 

### 2. **Backend Setup** (Core)
- [ ] \`backend/package.json\` + deps (express, mongoose, bcryptjs, jsonwebtoken, multer, cors, helmet, dotenv, zod)
- [ ] \`backend/server.js\` (Express app, port 5000)
- [ ] \`.env\` template (MONGODB_URI, JWT_SECRET, CLOUDINARY_*)
- [ ] \`backend/models/User.js\` (student/business schemas)
- [ ] \`backend/models/Post.js\`
- [ ] \`backend/models/Application.js\`

### 3. **Backend Auth APIs**
- [ ] \`backend/routes/auth.js\` (/register, /login → JWT)
- [ ] \`backend/middleware/auth.js\` (JWT verify)

### 4. **Backend Core APIs**
- [ ] \`backend/routes/posts.js\` (CRUD, multer upload)
- [ ] \`backend/routes/profiles.js\` (GET/PUT /profile)
- [ ] \`backend/routes/applications.js\` (POST /apply/:postId)
- [ ] \`backend/middleware/validation.js\` (zod schemas)

### 5. **Frontend Setup**
- [ ] \`frontend/package.json\` + \`npx create-vite@latest . --template react\` (Tailwind)
- [ ] TailwindCSS config (purple theme #7b3fe4)
- [ ] React Router setup

### 6. **Frontend Components (Reusable)**
- [ ] Navbar (auth-aware)
- [ ] PostCard, ProfileCard
- [ ] Forms (Register/Login/CreatePost w/ validation)

### 7. **Frontend Pages**
- [ ] Home/Landing (upgrade index.html)
- [ ] Feed (infinite scroll, posts)
- [ ] Dashboard (Student/Business)
- [ ] Profile (view/edit)
- [ ] CreatePost (Cloudinary upload)
- [ ] Search/Filter
- [ ] Apply modal/system

### 8. **Frontend State/UX**
- [ ] Auth Context (login/logout/persist)
- [ ] API service (axios w/ interceptors)
- [ ] Toast notifications (react-hot-toast)
- [ ] Loading spinners/errors

### 9. **Integrations**
- [ ] Cloudinary setup (env vars)
- [ ] MongoDB Atlas connection

### 10. **Testing & Polish**
- [ ] Test all flows (Postman + browser)
- [ ] Error handling/responsiveness
- [ ] README.md (setup/run/deploy)

### 11. **Production**
- [ ] CORS/prod middleware
- [ ] Rate limiting
- [ ] Deploy instructions (Render/Vercel + Railway)

